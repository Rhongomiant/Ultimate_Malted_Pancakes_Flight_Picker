# @psc/https

HTTP→HTTPS redirect + HSTS middleware for managed Node apps. Published by [PerankhSetuCura (PSC)](https://github.com/Rhongomiant/PerankhSetuCura). Express + Hono adapters from a single import. Pure ESM. Zero `@psc/*` runtime dependencies.

## Install

```bash
pnpm add @psc/https
# peers — install the one(s) your app uses:
pnpm add express      # OR
pnpm add hono
```

`@psc/https` declares `express` and `hono` as **optional peer dependencies**. Install only the framework your app uses; the other adapter is tree-shaken out of your bundle.

## Quickstart — Express

```ts
import express from 'express';
import { pscHttpsExpress } from '@psc/https';

const app = express();

// Trust Railway's edge proxy so req.protocol resolves correctly.
// See "Trust-proxy semantics" below for why this is YOUR responsibility.
app.set('trust proxy', 1);

// Mount the middleware FIRST so the redirect happens before any route logic.
app.use(pscHttpsExpress());

app.get('/', (_req, res) => res.send('Hello over HTTPS'));
app.listen(process.env.PORT ?? 3000);
```

## Quickstart — Hono

```ts
import { Hono } from 'hono';
import { serve } from '@hono/node-server';
import { pscHttpsHono } from '@psc/https';

const app = new Hono();
app.use('*', pscHttpsHono());
app.get('/', (c) => c.text('Hello over HTTPS'));
serve({ fetch: app.fetch, port: Number(process.env.PORT ?? 3000) });
```

## What it does

1. Reads the `X-Forwarded-Proto` header (Railway terminates TLS at its edge and sets this header on the proxied request).
2. If the request arrived over HTTP, responds **301 Moved Permanently** with `Location: https://<host>/<path>?<query>` — same host, same path, same query.
3. If the request arrived over HTTPS, sets `Strict-Transport-Security: max-age=31536000; includeSubDomains` and calls `next()`.
4. Exposes `/__psc/version` returning `{ "name": "@psc/https", "version": "<semver>" }`. Used by PSC's fleet posture audit (`psc apps audit --middleware` in a future plan).

### Bypass list

By default `/healthz` and `/__psc/version` bypass the redirect. Railway's internal healthcheck hits `/healthz` over plain HTTP from inside its network, so 301'ing it would mark the deploy unhealthy. Override:

```ts
app.use(
  pscHttpsExpress({
    bypassRedirectPaths: ['/healthz', '/admin/probe', '/__psc/version'],
  }),
);
```

Bypassed paths still receive the HSTS header when served over HTTPS — `@psc/https` only suppresses HSTS on plain-HTTP responses (RFC 6797 invariant).

### HSTS options

```ts
app.use(
  pscHttpsExpress({
    hsts: {
      maxAge: 31_536_000,       // seconds; default 1 year
      includeSubDomains: true,  // default true
      preload: false,           // default false — see WARNING below
    },
  }),
);

// Disable HSTS entirely (header NOT set on any response):
app.use(pscHttpsExpress({ hsts: false }));
```

#### WARNING — HSTS preload commitment

Submitting your apex to [hstspreload.org](https://hstspreload.org) is a **one-way commitment**. Removal takes 6–12 weeks to propagate through Chrome stable, longer for Firefox and Safari. Read [hstspreload.org/removal](https://hstspreload.org/removal/) before enabling `preload: true`.

`@psc/https` defends in depth: `serializeHsts` throws `TypeError` at construction time if `preload: true` is combined with `maxAge < 31_536_000` (1 year) OR `includeSubDomains: false` — both are required by the preload list, and shipping an unpreloadable header you then submit is exactly the failure mode we want to catch before deploy.

### `/__psc/version`

GET `/__psc/version` returns `{ name: '@psc/https', version: '0.1.0' }` (the literal version of the installed package). The body is **pre-serialized at module load** — the handler never calls `JSON.stringify` per-request, never reads `process.env`, never validates input. It cannot throw synchronously.

If your app rate-limits aggressively, exempt `/__psc/version` from the rate limiter so PSC's posture audit can probe it reliably.

## Trust-proxy semantics

`pscHttpsExpress` does **NOT** call `app.set('trust proxy', ...)`. The middleware deliberately leaves trust-proxy configuration to the operator because edge topologies vary:

- **Railway**: `app.set('trust proxy', 1)` — trust the single Railway edge hop.
- **Direct exposure / no edge proxy**: leave `trust proxy` unset. The middleware still detects HTTPS via `req.socket.encrypted`.
- **Multi-hop ingress**: configure `trust proxy` per your topology; the middleware respects whatever `req.protocol` resolves to.

**Do NOT use `app.set('trust proxy', true)` in production.** It accepts any `X-Forwarded-*` header from any client, opening the spoofing surface PSC documents in its threat model.

The middleware uses **three independent signals** to detect HTTPS — `X-Forwarded-Proto: https`, `req.protocol === 'https'`, and `req.socket.encrypted === true`. Any one signal counts. Trust-proxy misconfiguration on the operator side falls back gracefully through the other two signals.

## Dual-load notes

`@psc/https` uses `Symbol.for('@psc/https/installed')` so dual-loads of the package — e.g., a transitive dependency that brings a second copy via npm's hoisting rules — do not double-execute the Express middleware. The first mount claims the app via the global symbol registry; subsequent mounts short-circuit to a no-op.

If you see a dual-load warning, pin a single version in your consumer:

```jsonc
// package.json
{
  "pnpm": {
    "overrides": { "@psc/https": "^0.1.0" }
  }
}
```

**Hono limitation in v0.1.x:** Hono's middleware context does not expose the host Hono `app` instance reliably, so double-`app.use('*', pscHttpsHono())` on the same Hono instance will execute the middleware twice on each request. Mount once. v0.2 may add a Hono-specific composition guard.

## Compatibility

| Runtime | Status |
| --- | --- |
| Node.js 20+ | yes |
| Express 4.17+ / 5.x | yes |
| Hono 4.x | yes |
| Cloudflare Workers (Hono) | should work (Web-standards) — not v1-tested |

## Source

Part of [PerankhSetuCura](https://github.com/Rhongomiant/PerankhSetuCura). Issues: [GitHub Issues](https://github.com/Rhongomiant/PerankhSetuCura/issues).

## License

MIT
